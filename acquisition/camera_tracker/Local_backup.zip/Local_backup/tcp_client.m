function [] = tcp_client()
    h = tcpip('localhost',80,'NetworkRole','client');
    fopen(h);
    
%     t_get = tcpip('132.64.61.62',88,'NetworkRole','server');
%     % Wait for connection
%     t_get.InputBufferSize = 512;
%     disp('Waiting for connection');
%     fopen(t_get);
    disp('Connection OK');
    i = 0;
    fwrite(h, 1:6);
%     while true
%         data = fread(t_get, 2);
%         if(data(1) == 0)
%             break;
%         end
%         fwrite(t_send, data);
%         i = i + 1
%     end

    pause(0.5);
%     for i = 1:10
%     fwrite(t_send, 1:200);
%     end
    disp('Finished sending!');
    disp('Finished sending!');
end