function test()
%%
    fclose(instrfind);
    robot_h = serial('COM3', 'BaudRate', 19200);
    fopen(robot_h);
    pause(2);
    disp('done');
    %%
    fwrite(robot_h, 'r');
    pause(0.1);
    fwrite(robot_h, 'x');
    disp('done');
    %%
    fwrite(robot_h, 'x');
    disp('done');
    %%
    fclose(robot_h)
    disp('done');

    %%
    fclose(instrfind);
    disp('done');
end